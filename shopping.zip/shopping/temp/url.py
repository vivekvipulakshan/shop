from django.urls import re_path
from temp import views


urlpatterns = [
    re_path('home/', views.home),
    re_path('admin/', views.admin),
    re_path('user/', views.user),

]