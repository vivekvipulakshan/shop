from django.urls import re_path
from cart import views

urlpatterns = [

    re_path('products/', views.prodvii),
    re_path('addcart/(?P<idd>\w+)', views.addcart, name="addcart"),
    re_path('cartvw/', views.cart),

]