from django.shortcuts import render
from cart.models import Cart
from user.models import User
from django.core.files.storage import FileSystemStorage
from products.models import Products



# Create your views here.
def prodvii(request):
    obj = Products.objects.all()
    context = {
        'x': obj
    }

    return render(request, 'cart/produtsvi.html', context)
def addcart(request,idd):
    obj = Products.objects.all()
    context = {
        'x': obj,
    }
    if request.method == 'POST':
        ss = request.session['u_id']
        ob = Cart(request)
        ob.product_name = obj.product_name
        ob.details = obj.category
        ob.price = obj.price
        ob.pro_id = obj.pro_id
        ob.user_id = ss
        ob.save()
        return prodvii(request)
    return render(request, 'cart/produtsvi.html', context)


def cart(request):
    ss = request.session['u_id']
    obj = Cart.objects.filter(user_id=ss)
    context = {
        'x': obj
    }
    return render(request, 'cart/cart.html',context)

# def product_index(request):
#
#     title = "My Products"
#     products = Products.objects.all()
#     order = get_cart(request)
#     cart = Order.objects.get(id=order.id, complete=False)
#     items = cart.orderitem_set.all()
#
#     # Changes
#     for product in products:
#         qty = 0
#         if items.filter(product=product).exists():
#             qty = items.get(product=product).quantity
#         setattr(product, 'quantity_in_cart', qty)
#
#     context = {
#     'title' : title,
#     'products' : products,
#     'cart' : cart,
#     'items': items
#     }
#     return render(request, "store/product_index.html", context)