from django.db import models
from products.models import Products
from user.models import User

# Create your models here.
class Cart(models.Model):
    cr_id = models.AutoField(primary_key=True)
    product_name = models.CharField(max_length=100)
    details = models.CharField(max_length=100)
    price = models.CharField(max_length=100)
    # pro_id = models.IntegerField()
    pro = models.ForeignKey(Products, to_field='pro_id', on_delete=models.CASCADE)
    # user_id = models.IntegerField()
    user = models.ForeignKey(User, to_field='user_id', on_delete=models.CASCADE)

    class Meta:
        managed = False
        db_table = 'cart'


