from django.shortcuts import render
from products.models import Products
from django.core.files.storage import FileSystemStorage
# Create your views here.
def pageprod(request):
    return render(request, 'products/product.html')
def addprd(request):
    if request.method == 'POST':
        obj = Products()
        obj.product_name = request.POST.get('pname')
        obj.category = request.POST.get('cat')
        obj.price = request.POST.get('pric')
        obj.quantity = request.POST.get('quant')
        myfile = request.FILES['image']
        fd = FileSystemStorage()
        filename = fd.save(myfile.name, myfile)
        obj.image = myfile.name
        myfile1 = request.FILES['video']
        fd1 = FileSystemStorage()
        filename = fd1.save(myfile1.name, myfile1)
        obj.video = myfile1.name
        obj.save()
    return render(request, 'products/addprod.html')
def vwproad(request):
    obj = Products.objects.all()
    context = {
        'x': obj,
    }
    return render(request, 'products/vwprod.html', context)
def upprod(request,idd):
    obj = Products.objects.get(pro_id=idd)
    context = {
        'x': obj,
    }
    if request.method == 'POST':
        obj = Products()
        obj.product_name = request.POST.get('pname')
        obj.category = request.POST.get('cat')
        obj.price = request.POST.get('pric')
        obj.quantity = request.POST.get('quant')
        myfile = request.FILES['image']
        fd = FileSystemStorage()
        filename = fd.save(myfile.name, myfile)
        obj.image = myfile.name
        myfile1 = request.FILES['video']
        fd1 = FileSystemStorage()
        filename = fd1.save(myfile1.name, myfile1)
        obj.video = myfile1.name
        obj.save()
        return vwproad(request)
    return render(request, 'products/upprod.html',context)
def delprod(request,idd):
    obj = Products.objects.get(pro_id=idd)
    obj.delete()
    return vwproad(request)

