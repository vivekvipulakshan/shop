from django.db import models

# Create your models here.
class Products(models.Model):
    pro_id = models.AutoField(primary_key=True)
    product_name = models.CharField(max_length=100)
    category = models.CharField(max_length=100)
    price = models.CharField(max_length=100)
    quantity = models.CharField(max_length=100)
    image = models.CharField(max_length=100)
    video = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'products'
