from django.urls import re_path
from products import views

urlpatterns = [
    re_path('prodpg/', views.pageprod),
    re_path('addpro/', views.addprd),
    re_path('vwpro/', views.vwproad),
    re_path('uptprod/(?P<idd>\w+)', views.upprod, name="upprod"),
    re_path('deletdct/(?P<idd>\w+)', views.delprod, name="delprod"),

]