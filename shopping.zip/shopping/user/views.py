from django.shortcuts import render
from django.shortcuts import render
from user.models import User
from login.models import Login
from django.core.files.storage import FileSystemStorage
from user.models import User,District,State,City
from django.http import HttpResponse, JsonResponse
from django.core import serializers
import json


def userg(request):
    obj = User.objects.all()
    stat_obj = State.objects.all()
    dist = District.objects.all()
    cit_obj = City.objects.all()
    context = {
        'x':obj,
        'stat': stat_obj,
        'y': cit_obj,
        'z': dist,

    }
    if request.method == 'POST':
        obj = User()
        obj.name = request.POST.get('name')
        obj.lname = request.POST.get('lname')
        obj.dob = request.POST.get('dob')
        obj.gender = request.POST.get('GENDER')
        obj.address = request.POST.get('ADDRESS')
        obj.email = request.POST.get('EMAIL')
        obj.password = request.POST.get('pass')
        obj.phone = request.POST.get('PHONE')
        obj.state = request.POST.get('stat')
        obj.district = request.POST.get('dict')
        obj.city = request.POST.get('cit')
        obj.pincode = request.POST.get('pincode')
        obj.landmark = request.POST.get('land')
        obj.save()
        ob = Login()
        ob.username = obj.email
        ob.password = obj.password
        ob.type = 'user'
        ob.u_id = obj.user_id
        ob.save()
        # return msg(request)
    return render(request, 'user/userreg.html',context)
# def get_district(request):
#     stat = request.POST.get('stat')
#     d_obj = District.objects.filter(distr_id=stat).values()
#     return JsonResponse({'dict': list(d_obj)})
# def msg(request):
#     return render(request, 'user/msg.html')

# Create your views here.
