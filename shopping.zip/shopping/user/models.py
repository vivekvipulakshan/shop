from django.db import models

# Create your models here.
class User(models.Model):
    user_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100)
    lname = models.CharField(max_length=100)
    age = models.CharField(max_length=100)
    gender = models.CharField(max_length=100)
    address = models.CharField(max_length=100)
    email_id = models.CharField(max_length=100)
    password = models.CharField(max_length=100)
    phone = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    city = models.CharField(max_length=100)
    pincode = models.CharField(max_length=100)
    landmark = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'user'

class City(models.Model):
    ci_id = models.AutoField(primary_key=True)
    city_name = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'city'

class District(models.Model):
    distr_id = models.AutoField(primary_key=True)
    distr_name = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'district'

class State(models.Model):
    st_id = models.AutoField(primary_key=True)
    state_name = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'state'
