from django.urls import re_path
from user import views

urlpatterns = [

    re_path('userreg/', views.userg),
    # re_path('get_district/', views.get_district),

]