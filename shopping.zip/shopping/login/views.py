from django.shortcuts import render
from django.shortcuts import render
from django.http import HttpResponseRedirect
from login.models import Login
import itertools
import uuid


# Create your views here.
def login(request):
    if request.method == 'POST':
        name = request.POST.get('Username')
        password = request.POST.get('password')
        obj = Login.objects.filter(username=name, password=password)
        tp = ''
        for ob in obj:
            tp = ob.type
            uid = ob.u_id
            if tp == 'user':
                request.session['u_id'] = uid
                return HttpResponseRedirect('/temp/user/')
            elif tp == 'admin':
                request.session['u_id'] = uid
                return HttpResponseRedirect('/temp/admin/')
        else:
                objlist="username or password is incorrrect.......!"
                context={
                    'msg':objlist,
                  }
                return render(request,'login/login.html',context)
    return render(request, 'login/login.html')

# Create your views here.
